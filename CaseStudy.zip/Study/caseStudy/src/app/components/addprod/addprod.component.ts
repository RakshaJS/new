import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProdService } from 'src/app/services/prod.service';

@Component({
  selector: 'app-addprod',
  templateUrl: './addprod.component.html',
  styleUrls: ['./addprod.component.css']
})
export class AddprodComponent implements OnInit {
  addForm:FormGroup;
  submitted: boolean=false;
  
    constructor( private router:Router,
       private productservice: ProdService) { }
  
    ngOnInit() {
      this.addForm= new FormGroup({
        id:new FormControl('',[Validators.required, Validators.pattern('[0-9]{1,4}')]),
        name: new FormControl('',[Validators.required, Validators.pattern('[A-Z][a-zA-Z]+')]),
        description:new FormControl('', [Validators.required]),
        price:new FormControl('', [Validators.required])
        })
          }
    
    onSubmit(){
      this.submitted=true;
      if(this.addForm.invalid){
        return;
      }
      this.productservice.createProduct(this.addForm.value).subscribe(data=>
        {
          alert('record added');
        });
        this.router.navigate(['prodlist']);
    }


}
