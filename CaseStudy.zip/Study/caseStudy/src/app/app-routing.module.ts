import { NgModule } from '@angular/core';
import { Routes, RouterModule,PreloadAllModules   } from '@angular/router';
import { ProdlistComponent } from './components/prodlist/prodlist.component';
import { AddprodComponent } from './components/addprod/addprod.component';
import { EditprodComponent } from './components/editprod/editprod.component';

const routes: Routes = [
  {path:'',component:ProdlistComponent},
  {path:'prodlist', component:ProdlistComponent},
  {path:'addprod', component:AddprodComponent},
  {path:'editprod', component:EditprodComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {preloadingStrategy: PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
